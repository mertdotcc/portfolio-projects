import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.*;

public class SignUpFrame extends JFrame{
    JButton button;
    JComponent panel;
    JLabel label1;
    JLabel label2;
    JLabel label3;
    JLabel label4;
    JLabel label5;
    JLabel label6;
    JLabel label7;
    JLabel label8;

    JTextField text1;
    JTextField text2;
    JTextField text3;
    JTextField text4;
    JTextField text5;
    JTextField text6;
    JTextField text7;
    JTextField text8;

    JPanel empty;

    public SignUpFrame() {
        createComponents();

        panel.setLayout( new GridLayout(9,2));

        createPanel();
        this.add(panel);
        this.setSize(1920,1080);
        this.setVisible(true);
    }

    public void createComponents() {
        button = new JButton("Sign Up");
        panel = new JPanel();
        empty = new JPanel();

        label1 = new JLabel("Username: ");
        label2 = new JLabel("Name: ");
        label3 = new JLabel("Age: ");
        label4 = new JLabel("Height: ");
        label5 = new JLabel("Weight: ");
        label6 = new JLabel("Password: ");
        label7 = new JLabel("Re-type password: ");
        label8 = new JLabel("Favorite Animal: ");

        text1 = new JTextField(40);
        text2 = new JTextField(40);
        text3 = new JTextField(40);
        text4 = new JTextField(40);
        text5 = new JTextField(40);
        text6 = new JTextField(40);
        text7 = new JTextField(40);
        text8 = new JTextField(40);


    }

    public void createPanel() {
        panel.add(label1);
        panel.add(text1);
        panel.add(label2);
        panel.add(text2);
        panel.add(label3);
        panel.add(text3);
        panel.add(label4);
        panel.add(text4);
        panel.add(label5);
        panel.add(text5);
        panel.add(label6);
        panel.add(text6);
        panel.add(label7);
        panel.add(text7);
        panel.add(label8);
        panel.add(text8);
        panel.add(empty);
        panel.add(button);

        panel.setBorder(new TitledBorder(new EtchedBorder(),"SIGN UP"));

    }
}

