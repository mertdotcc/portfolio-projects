import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class MainMenuPanel extends JPanel {

    public JPanel humanImage;
    public JPanel panelOfActivities;
    public PieChart generalPieChart;
    public PieChart activityPieChart;
    public JPanel cycleImage;
    public JPanel lambImage;
    public JPanel bedImage;
    public JPanel facebookImage;
    public JPanel podiumImage;
    public JButton addActivityButton;
    public JButton updateActivityButton;
    public JButton createActivityButton;
    public DailyActivityList dailyActivities;

    public MainMenuPanel() {
        setLayout(null);
        //initiate buttons
        addActivityButton = new JButton();
        addActivityButton.setIcon(new ImageIcon("addbutton2.png"));
        addActivityButton.setSize(25,25);
        updateActivityButton = new JButton();
        updateActivityButton.setIcon(new ImageIcon("updatebutton2.jpg"));
        updateActivityButton.setSize(25,25);

        //initiate panel for activities
        panelOfActivities = new JPanel();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        Date date = new Date(now.getYear(), now.getDayOfMonth(),now.getDayOfYear());

        //initialize activities
        dailyActivities = new DailyActivityList( date , new ArrayList<Activity>());
        dailyActivities.addActivity(new Activity("Sport"));
        dailyActivities.addActivity(new Activity("Sleep"));
        dailyActivities.addActivity(new Activity("Work"));
        dailyActivities.addActivity(new Activity("Social"));
        //set layout of activity panel
        switch ( dailyActivities.getActivities().size() % 2) {
            case 0:
                panelOfActivities.setLayout(new GridLayout(dailyActivities.getActivities().size() / 2, 2));
                break;
            case 1:
                panelOfActivities.setLayout(new GridLayout((dailyActivities.getActivities().size() + 1)/2, 2));
                break;
        }
        for(int i = 0; i < dailyActivities.getActivities().size(); i++) {
            JPanel tempNorth = new JPanel();
            tempNorth.setLayout(new GridLayout(1,3));
            JPanel back = new JPanel();
            back.setLayout(new BorderLayout());
            //tempNorth.add(addActivityButton);
            tempNorth.add(new JLabel(dailyActivities.getActivities().get(i).getName()));
            tempNorth.add(updateActivityButton);
            back.add(tempNorth,BorderLayout.NORTH);
            //add charts here
            panelOfActivities.add(back);
        }
        panelOfActivities.setBounds(500,100,500,500);
        add(panelOfActivities);
    }
}
