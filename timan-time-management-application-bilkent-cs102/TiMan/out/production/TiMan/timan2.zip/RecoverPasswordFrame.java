import javax.swing.*;
import java.awt.*;

public class RecoverPasswordFrame extends JFrame {

    public JLabel recoverLabel;
    public JLabel username;
    public JLabel favAnimal;
    public JLabel yourPassword;
    public JButton savePassword;
    public JButton loginpage;
    public JPanel backPanel;
    public JPanel midPanel;
    public JTextField usernameField;
    public JTextField favAnimalField;
    public JTextField passwordField;

    public RecoverPasswordFrame() {
        recoverLabel = new JLabel("Recover your password");
        username = new JLabel("Username: ");
        favAnimal = new JLabel("Your Favourite animal: ");
        yourPassword = new JLabel("Your password is: ");
        savePassword = new JButton("Recover password");
        loginpage = new JButton("Login Page");
        usernameField = new JTextField();
        favAnimalField = new JTextField();
        passwordField = new JTextField();

        backPanel = new JPanel();
        backPanel.setLayout(new BorderLayout());
        midPanel = new JPanel();
        midPanel.setLayout( new GridLayout(5,1));
        JPanel panel1 = new JPanel();
        panel1.add(username);
        panel1.add(usernameField);
        midPanel.add(panel1);
        JPanel panel2 = new JPanel();
        panel2.add(favAnimal);
        panel2.add(favAnimalField);
        midPanel.add(panel2);
        midPanel.add(savePassword);
        JPanel panel3 = new JPanel();
        panel3.add(yourPassword);
        panel3.add(passwordField);
        midPanel.add(panel3);
        midPanel.add(loginpage);
        backPanel.add(recoverLabel,BorderLayout.NORTH);
        backPanel.add(midPanel,BorderLayout.CENTER);

        add(backPanel);
        setSize(800,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
