import javax.swing.*;
import java.util.ArrayList;

public class MainManuFrame extends JFrame {
    public JTabbedPane pane;
    public ArrayList<Activity> activities;
    public MainManuFrame() {
        activities = new ArrayList<Activity>();
        activities.add(new Activity("Sport"));
        activities.add(new Activity("Sleep"));
        activities.add(new Activity("Work"));
        activities.add(new Activity("Social"));
        pane = new JTabbedPane();
        pane.addTab("Main Menu",new MainMenuPanel());
        for( int i = 0; i < activities.size(); i++) {
            pane.addTab(activities.get(i).getName(),new UpdateActivityPanel(activities.get(i)));
        }
        add(pane);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(2500,2000);
        setVisible(true);
    }
}
