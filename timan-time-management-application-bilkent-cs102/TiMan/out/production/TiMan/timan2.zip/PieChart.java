import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.PieDataset;

import javax.swing.*;

public class PieChart extends JPanel {

    public PieDataset dataset;
    public JFreeChart chart;

    public PieChart( PieDataset dataset, String chartTitle, boolean includeLegend) {
        this.dataset = dataset;
        chart = ChartFactory.createPieChart(
                "Mobile Sales",   // chart title
                dataset,          // data
                includeLegend,             // include legend
                true,
                false);

        //add(chart);
    }
}
