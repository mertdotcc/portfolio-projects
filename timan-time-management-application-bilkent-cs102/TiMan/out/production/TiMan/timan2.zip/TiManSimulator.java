import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class TiManSimulator {
   /* private ArrayList<User> users;

   /* public TiManSimulator() {
        //Scanner fileScan = new Scanner("")
    }
*/
   public static void main (String args[]) {
       /*SwingUtilities.invokeLater(new Runnable() {
           public void run() {
               new JImageComponent();
           }
       });*/
       LoginPageFrame l = new LoginPageFrame();
       RecoverPasswordFrame r = new RecoverPasswordFrame();
       MainManuFrame f = new MainManuFrame();
       SignUpFrame ff = new SignUpFrame();
       SettingsFrame s = new SettingsFrame();
   }


}
