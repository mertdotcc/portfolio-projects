import javax.swing.*;
import java.awt.*;

public class LoginPageFrame extends JFrame {
    private JPanel panelBack;
    private JPanel leftPanel;
    private JPanel rightPanel;
    private JLabel logo;
    private WelcomeLabelPanel welcome;
    private JLabel login;
    private JLabel username;
    private JLabel password;
    private JTextField userNameField;
    private JTextField passwordField;
    private JButton loginButton;
    private JButton signUpButton;
    private JButton forgotPasswordButton;

    public LoginPageFrame() {
        panelBack = new JPanel();
        panelBack.setLayout(new GridLayout(1,2));

        leftPanel = new JPanel();
        leftPanel.setLayout(new GridLayout(1,2));
        JPanel rightBackPanel = new JPanel();
        rightBackPanel.setLayout(new BorderLayout());
        rightPanel = new JPanel();
        rightPanel.setLayout(new GridLayout(4,2));
        logo = new JLabel(new ImageIcon("logo.JPG"));
        welcome = new WelcomeLabelPanel();
        login = new JLabel("Login");
        username = new JLabel("Username");
        password = new JLabel("Password");
        userNameField = new JTextField();
        passwordField = new JTextField();
        loginButton = new JButton("Login");
        signUpButton = new JButton("Sign Up");
        forgotPasswordButton = new JButton("Forgot Password?");
        //JImageComponent c = new JImageComponent("logo.JPG");
        leftPanel.add(logo);
        //logo.setBounds(100,100,60,60);
        //panelBack.add(c);
        //welcome.setBounds(100,100,60,60);
        //panelBack.add(welcome);
        leftPanel.add(welcome);

        rightBackPanel.add(login,BorderLayout.NORTH);
        rightPanel.add(username);
        rightPanel.add(userNameField);
        rightPanel.add(password);
        rightPanel.add(passwordField);
        rightPanel.add(loginButton);
        rightPanel.add(forgotPasswordButton);
        rightPanel.add(signUpButton);
        rightBackPanel.add(rightPanel,BorderLayout.CENTER);

        panelBack.add(leftPanel);
        panelBack.add(rightBackPanel);

        add(panelBack);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("TiMan");
        setSize(800,600);
        setVisible(true);
    }

    class WelcomeLabelPanel extends JPanel {

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawString("Welcome to TiMan",125,250);

            }
    }

}
