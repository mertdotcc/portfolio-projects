import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.*;

public class UpdateActivityPanel extends JPanel {

    JPanel mainPanel;
    JLabel label1;
    JLabel label2;
    JLabel label3;

    JTextField text1;
    JTextField text2;
    Activity activity;

    JPanel empty;

    JButton button;

    public UpdateActivityPanel(Activity a) {
        mainPanel = new JPanel();
        this.setLayout(new BorderLayout());
        mainPanel.setLayout(new GridLayout(3,2));
        createComponents();
        mainPanel.add(label1);
        mainPanel.add(text1);
        mainPanel.add(label2);
        mainPanel.add(text2);
        mainPanel.add(empty);
        mainPanel.add(button);
        activity = a;
        label3 = new JLabel("Update Activity - " + activity.getName());
        this.add(label3, BorderLayout.NORTH);
        this.add(mainPanel, BorderLayout.CENTER);
    }

    public void createComponents() {
        label1 = new JLabel("Rename");
        label2 = new JLabel("Enter Goal(per week)");
        text1 = new JTextField();
        text2 = new JTextField();

        empty = new JPanel();

        button = new JButton("Update Activity");
        button.addActionListener(new ButtonListener());
    }

    class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if(!text1.getText().equals("")) {
                activity.setName(text1.getText());
                repaint();
            }
            else if( !text2.getText().equals("")) {
                activity.setGoalPerWeek(Integer.valueOf(text2.getText()));
                repaint();
            }
        }
    }
}
